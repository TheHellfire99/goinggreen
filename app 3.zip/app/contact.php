<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="shortcut icon" href="https://cdn.glitch.com/eed552fa-10a9-43b6-aec1-9192c4591424%2Ffavicon.ico?1553371281306" type="image/x-icon">
    <link rel="stylesheet" href="style.css">
    <script src="/script.js" defer></script>
 <link href="https://fonts.googleapis.com/css?family=Abel|Anton|Baloo+Chettan|Germania+One|Lato|Libre+Baskerville|Lora|Margarine|Montserrat|Noto+Sans|Open+Sans|Open+Sans+Condensed:300|Oswald|Playfair+Display|Roboto|Roboto+Condensed|Source+Sans+Pro" rel="stylesheet">
 <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o" crossorigin="anonymous"></script>
  <link href="https://fonts.googleapis.com/css?family=Questrial" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
<title>Contact</title>
 <script async>(function(w, d) { w.CollectId = "5c973a1ed51d1558ddef6ba2"; var h = d.head || d.getElementsByTagName("head")[0]; var s = d.createElement("script"); s.setAttribute("type", "text/javascript"); s.setAttribute("src", "https://collectcdn.com/launcher.js"); h.appendChild(s); })(window, document);</script> </head>  
  <body>
    <section id="home">
       <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="index.html">
    <img src="https://cdn.glitch.com/eed552fa-10a9-43b6-aec1-9192c4591424%2FScreenshot%202019-03-23%20at%201.23.10%20PM.png?1553372621592" width="30" height="30" class="d-inline-block align-top" alt="">
    Going Green 
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="features.html">Features</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="donations.html">Donations</a>
      </li>
         <li class="nav-item">
        <a class="nav-link" href="contact.html">Contact Us</a>
      </li>
      
    </ul>
  </div>
     </nav>
         <h1 class="title">Contact Us</h1>
          <div class="line"></div>
        <h1 class="tgay">We would love to listen to your suggestion and questions. If you would like to talk to us personally, Our google number is +1 51023933 . if you have any ideas please feel free to share.</h1>
      </section>
      <section class="form">
       <main>
          
           <form class="contact-form" action="contactform.php" method="post">
           <input type="text" name="name" placeholder="full name">
           <input type="text" name="mail" placeholder="Email">
            <input type="text" name="Subject" placeholder="Subject">
            <textarea name="message" placeholder="message" rows="8" cols="80"></textarea> 
               <button type="submit" name="submit">Send message</button>
           
           </form>
          
          
          
      </main>

    </section>
  </body>
</html>
